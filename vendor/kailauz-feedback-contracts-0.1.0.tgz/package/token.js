'use strict';

const { createHmac, timingSafeEqual } = require('node:crypto');

function encode(value) {
  return Buffer.from(typeof value === 'string' ? value : JSON.stringify(value)).toString('base64url');
}

function decode(value) {
  return JSON.parse(Buffer.from(value, 'base64url').toString('utf8'));
}

function signFeedbackToken(claims, secret) {
  if (typeof secret !== 'string' || secret.length < 32) throw new Error('Feedback token secret is too short');
  const header = encode({ alg: 'HS256', typ: 'JWT' });
  const payload = encode(claims);
  const content = `${header}.${payload}`;
  const signature = createHmac('sha256', secret).update(content).digest('base64url');
  return `${content}.${signature}`;
}

function verifyFeedbackToken(token, secret, options = {}) {
  const parts = String(token || '').split('.');
  if (parts.length !== 3) throw new Error('Invalid feedback token');
  const [headerPart, payloadPart, signaturePart] = parts;
  const header = decode(headerPart);
  if (header.alg !== 'HS256' || header.typ !== 'JWT') throw new Error('Invalid feedback token header');
  const expected = createHmac('sha256', secret).update(`${headerPart}.${payloadPart}`).digest();
  const actual = Buffer.from(signaturePart, 'base64url');
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) throw new Error('Invalid feedback token signature');
  const claims = decode(payloadPart);
  const now = Math.floor((options.nowMs || Date.now()) / 1000);
  if (!Number.isSafeInteger(claims.iat) || !Number.isSafeInteger(claims.exp) || claims.iat > now + 30 || claims.exp <= now) {
    throw new Error('Feedback token expired or invalid');
  }
  if (claims.exp - claims.iat > (options.maxLifetimeSeconds || 600)) throw new Error('Feedback token lifetime is invalid');
  if (options.issuer && claims.iss !== options.issuer) throw new Error('Invalid feedback token issuer');
  if (options.audience && claims.aud !== options.audience) throw new Error('Invalid feedback token audience');
  return claims;
}

module.exports = { signFeedbackToken, verifyFeedbackToken };

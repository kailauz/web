import type { FeedbackRole } from './index';

export interface FeedbackTokenClaims {
  iss: string;
  aud: string;
  sub: string;
  iat: number;
  exp: number;
  jti: string;
  tenant_id: string;
  product_id: string;
  roles: FeedbackRole[];
  beta_access: boolean;
  display_alias?: string;
}

export function signFeedbackToken(claims: FeedbackTokenClaims, secret: string): string;
export function verifyFeedbackToken(
  token: string,
  secret: string,
  options?: { issuer?: string; audience?: string; maxLifetimeSeconds?: number; nowMs?: number },
): FeedbackTokenClaims;

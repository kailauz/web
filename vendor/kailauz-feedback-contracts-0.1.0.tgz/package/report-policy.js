'use strict';

const BUG_STATUSES = Object.freeze(['submitted', 'triage', 'needs_info', 'confirmed', 'in_progress', 'fixed', 'verification', 'closed']);
const IDEA_STATUSES = Object.freeze(['new', 'needs_info', 'considering', 'planned', 'in_progress', 'shipped', 'not_planned']);
const REPORT_RESOLUTIONS = Object.freeze(['duplicate', 'cannot_reproduce', 'expected_behavior', 'out_of_scope', 'will_not_fix', 'private_security']);
const REPORT_SEVERITIES = Object.freeze(['blocker', 'critical', 'major', 'minor', 'cosmetic']);
const REPORT_FREQUENCIES = Object.freeze(['always', 'sometimes', 'once', 'cannot_reproduce']);
const REPORT_IMPACTS = Object.freeze(['unusable', 'core_flow_broken', 'workaround', 'disruptive', 'visual']);
const FEEDBACK_ROLES = Object.freeze(['reporter', 'triager', 'developer', 'moderator', 'administrator']);
const SENSITIVE_CATEGORIES = Object.freeze(['security', 'privacy', 'abuse', 'sexual_content']);
const BUG_TRANSITIONS = Object.freeze({
  submitted: ['triage', 'needs_info'], triage: ['needs_info', 'confirmed'],
  needs_info: ['triage', 'confirmed'], confirmed: ['in_progress'], in_progress: ['fixed'],
  fixed: ['verification'], verification: ['closed', 'in_progress'], closed: ['in_progress'],
});
const IDEA_TRANSITIONS = Object.freeze({
  new: ['needs_info', 'considering'], needs_info: ['considering'], considering: ['planned', 'not_planned'],
  planned: ['in_progress', 'not_planned'], in_progress: ['shipped', 'planned'],
  shipped: ['in_progress'], not_planned: ['considering'],
});

function normalizeCreateReport(value) {
  const input = object(value);
  rejectFields(input, ['severity', 'resolution', 'status', 'reward', 'reward_points', 'canonical_report_id']);
  const common = {
    kind: enumValue(input.kind, ['bug', 'idea'], 'kind'),
    idempotency_key: compact(input.idempotency_key, 'idempotency_key', 16, 120),
    title: compact(input.title, 'title', 8, 140),
  };
  if (common.kind === 'bug') {
    const diagnosticsConsent = input.diagnostics_consent === true;
    return {
      ...common,
      kind: 'bug',
      attempted: compact(input.attempted, 'attempted', 12, 2000),
      actual: compact(input.actual, 'actual', 12, 2000),
      expected: compact(input.expected, 'expected', 12, 2000),
      reproduction_steps: stringList(input.reproduction_steps, 'reproduction_steps', 1, 12, 4, 500),
      frequency: enumValue(input.frequency, REPORT_FREQUENCIES, 'frequency'),
      impact: enumValue(input.impact, REPORT_IMPACTS, 'impact'),
      sensitive_category: input.sensitive_category == null ? null : enumValue(input.sensitive_category, SENSITIVE_CATEGORIES, 'sensitive_category'),
      diagnostics_consent: diagnosticsConsent,
      ...(diagnosticsConsent ? { diagnostics: normalizeDiagnostics(input.diagnostics) } : {}),
    };
  }
  return {
    ...common,
    kind: 'idea',
    problem: compact(input.problem, 'problem', 12, 2000),
    context: compact(input.context, 'context', 8, 2000),
    current_workaround: optional(input.current_workaround, 1000, 'current_workaround'),
    beneficiaries: compact(input.beneficiaries, 'beneficiaries', 4, 1000),
    proposed_solution: optional(input.proposed_solution, 2000, 'proposed_solution'),
  };
}

function normalizeTriageUpdate(value, current) {
  const input = object(value);
  const nextStatus = input.status === undefined ? current.status : compact(input.status, 'status', 2, 40);
  const allowedStatuses = current.kind === 'bug' ? BUG_STATUSES : IDEA_STATUSES;
  if (!allowedStatuses.includes(nextStatus)) throw new TypeError('Invalid status for report kind');
  if (nextStatus !== current.status) {
    const transitions = current.kind === 'bug' ? BUG_TRANSITIONS : IDEA_TRANSITIONS;
    if (!transitions[current.status]?.includes(nextStatus)) throw new TypeError('Invalid status transition');
  }
  const resolution = input.resolution == null ? null : enumValue(input.resolution, REPORT_RESOLUTIONS, 'resolution');
  const severity = input.severity == null ? null : enumValue(input.severity, REPORT_SEVERITIES, 'severity');
  if (current.kind !== 'bug' && severity) throw new TypeError('Severity applies only to bugs');
  if (severity && !['confirmed', 'in_progress', 'fixed', 'verification', 'closed'].includes(nextStatus)) {
    throw new TypeError('Severity requires a reproduced and confirmed bug');
  }
  if (resolution === 'duplicate' && !input.canonical_report_id) throw new TypeError('canonical_report_id is required for duplicates');
  return {
    status: nextStatus, resolution, severity,
    canonical_report_id: input.canonical_report_id == null ? null : uuid(input.canonical_report_id, 'canonical_report_id'),
    public_note: compact(input.public_note, 'public_note', 4, 1000),
    fixed_version: optional(input.fixed_version, 120, 'fixed_version'),
  };
}

function normalizeDiagnostics(value) {
  const input = object(value || {});
  rejectFields(input, ['email', 'token', 'access_token', 'refresh_token', 'library', 'content', 'text']);
  return {
    screen: optional(input.screen, 120, 'screen'), build: optional(input.build, 80, 'build'), os: optional(input.os, 80, 'os'),
    device_model: optional(input.device_model, 120, 'device_model'), locale: optional(input.locale, 20, 'locale'),
    correlation_ids: stringList(input.correlation_ids || [], 'correlation_ids', 0, 8, 1, 120),
  };
}
function object(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new TypeError('JSON object is required');
  return value;
}
function compact(value, name, min, max) {
  const normalized = String(value || '').trim().replace(/\s+/g, ' ');
  if (normalized.length < min || normalized.length > max) throw Object.assign(new TypeError(`${name} must contain ${min}-${max} characters`), { field: name, min, max, kind: 'text_length' });
  return normalized;
}
function optional(value, max, name) {
  const normalized = String(value || '').trim().replace(/\s+/g, ' ');
  if (normalized.length > max) throw Object.assign(new TypeError(`Optional text exceeds ${max} characters`), { field: name, min: 0, max, kind: 'text_length' });
  return normalized || undefined;
}
function stringList(value, name, minItems, maxItems, min, max) {
  if (!Array.isArray(value) || value.length < minItems || value.length > maxItems) throw Object.assign(new TypeError(`${name} must contain ${minItems}-${maxItems} items`), { field: name, min: minItems, max: maxItems, kind: 'item_count' });
  return value.map((entry, index) => compact(entry, `${name}[${index}]`, min, max));
}
function enumValue(value, allowed, name) {
  if (!allowed.includes(value)) throw new TypeError(`${name} is invalid`);
  return value;
}
function uuid(value, name) {
  const normalized = String(value || '').trim();
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(normalized)) throw new TypeError(`${name} must be a UUID`);
  return normalized;
}
function rejectFields(input, names) {
  const found = names.find((name) => input[name] !== undefined);
  if (found) throw new TypeError(`${found} is managed by the development team`);
}

module.exports = {
  BUG_STATUSES, IDEA_STATUSES, REPORT_RESOLUTIONS, REPORT_SEVERITIES, REPORT_FREQUENCIES,
  REPORT_IMPACTS, FEEDBACK_ROLES, SENSITIVE_CATEGORIES, BUG_TRANSITIONS, IDEA_TRANSITIONS,
  normalizeCreateReport, normalizeTriageUpdate,
};

export type FeedbackReportKind = 'bug' | 'idea';
export type BugStatus = 'submitted' | 'triage' | 'needs_info' | 'confirmed' | 'in_progress' | 'fixed' | 'verification' | 'closed';
export type IdeaStatus = 'new' | 'needs_info' | 'considering' | 'planned' | 'in_progress' | 'shipped' | 'not_planned';
export type FeedbackResolution = 'duplicate' | 'cannot_reproduce' | 'expected_behavior' | 'out_of_scope' | 'will_not_fix' | 'private_security';
export type FeedbackSeverity = 'blocker' | 'critical' | 'major' | 'minor' | 'cosmetic';
export type FeedbackFrequency = 'always' | 'sometimes' | 'once' | 'cannot_reproduce';
export type FeedbackImpact = 'unusable' | 'core_flow_broken' | 'workaround' | 'disruptive' | 'visual';
export type FeedbackRole = 'reporter' | 'triager' | 'developer' | 'moderator' | 'administrator';
export type SensitiveCategory = 'security' | 'privacy' | 'abuse' | 'sexual_content';

export interface DiagnosticContext {
  screen?: string;
  build?: string;
  os?: string;
  device_model?: string;
  locale?: string;
  correlation_ids?: string[];
}

export interface CreateBugInput {
  kind: 'bug';
  idempotency_key: string;
  title: string;
  attempted: string;
  actual: string;
  expected: string;
  reproduction_steps: string[];
  frequency: FeedbackFrequency;
  impact: FeedbackImpact;
  sensitive_category?: SensitiveCategory | null;
  diagnostics_consent?: boolean;
  diagnostics?: DiagnosticContext;
}

export interface CreateIdeaInput {
  kind: 'idea';
  idempotency_key: string;
  title: string;
  problem: string;
  context: string;
  current_workaround?: string;
  beneficiaries: string;
  proposed_solution?: string;
}

export type CreateFeedbackReportInput = CreateBugInput | CreateIdeaInput;

export interface FeedbackReport {
  id: string;
  public_number: string | number;
  kind: FeedbackReportKind;
  title: string;
  status: BugStatus | IdeaStatus;
  resolution?: FeedbackResolution | null;
  canonical_report_id?: string | null;
  severity?: FeedbackSeverity | null;
  fixed_version?: string | null;
  content: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}
export interface FeedbackReportList { items: FeedbackReport[]; limit: number; offset: number; }
export interface FeedbackReportDetails extends FeedbackReport {
  comments: { id: string; author_alias?: string | null; body: string; created_at: string }[];
  history: { id: string; actor_alias?: string | null; from_status?: string | null; to_status?: string | null; public_note?: string | null; created_at: string }[];
  viewer_can_verify: boolean;
}

export interface FeedbackClientOptions {
  baseUrl: string;
  getToken: () => string | Promise<string>;
  fetch?: typeof fetch;
}

export class FeedbackClient {
  constructor(options: FeedbackClientOptions);
  request(path: string, init?: RequestInit): Promise<unknown>;
  getConfig(signal?: AbortSignal): Promise<unknown>;
  listReports(query?: string, signal?: AbortSignal): Promise<FeedbackReportList>;
  getReport(id: string, signal?: AbortSignal): Promise<FeedbackReportDetails>;
  createReport(input: CreateFeedbackReportInput): Promise<FeedbackReport>;
  addComment(id: string, input: { body: string; idempotency_key: string }): Promise<unknown>;
  verifyFix(id: string, input: { outcome: 'fixed' | 'still_broken'; note: string }): Promise<unknown>;
  updateTriage(id: string, input: Record<string, unknown>): Promise<unknown>;
}

export const BUG_STATUSES: readonly BugStatus[];
export const IDEA_STATUSES: readonly IdeaStatus[];
export const REPORT_RESOLUTIONS: readonly FeedbackResolution[];
export const REPORT_SEVERITIES: readonly FeedbackSeverity[];
export const REPORT_FREQUENCIES: readonly FeedbackFrequency[];
export const REPORT_IMPACTS: readonly FeedbackImpact[];
export const FEEDBACK_ROLES: readonly FeedbackRole[];
export const SENSITIVE_CATEGORIES: readonly SensitiveCategory[];
export const BUG_TRANSITIONS: Readonly<Record<string, readonly string[]>>;
export const IDEA_TRANSITIONS: Readonly<Record<string, readonly string[]>>;
export function normalizeCreateReport(value: unknown): CreateFeedbackReportInput;
export function normalizeTriageUpdate(value: unknown, current: { kind: string; status: string }): {
  status: string; resolution: FeedbackResolution | null; severity: FeedbackSeverity | null;
  canonical_report_id: string | null; public_note: string; fixed_version?: string;
};

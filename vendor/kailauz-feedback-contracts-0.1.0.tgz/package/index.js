'use strict';

const reportPolicy = require('./report-policy');

class FeedbackClient {
  constructor(options) {
    this.baseUrl = String(options.baseUrl || '').replace(/\/$/, '');
    this.getToken = options.getToken;
    this.fetch = options.fetch || globalThis.fetch;
    if (!this.baseUrl || typeof this.getToken !== 'function' || typeof this.fetch !== 'function') {
      throw new TypeError('baseUrl, getToken and fetch are required');
    }
  }

  async request(path, init = {}) {
    const token = await this.getToken();
    const response = await this.fetch(`${this.baseUrl}${path}`, {
      ...init,
      headers: {
        Accept: 'application/json',
        ...(init.body === undefined ? {} : { 'Content-Type': 'application/json' }),
        ...init.headers,
        Authorization: `Bearer ${token}`,
      },
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok) {
      const error = new Error(payload?.message || 'Feedback request failed');
      error.code = payload?.code || 'FEEDBACK_REQUEST_FAILED';
      error.status = response.status;
      throw error;
    }
    return payload;
  }

  getConfig(signal) { return this.request('/v1/config', { signal }); }
  listReports(query = '', signal) { return this.request(`/v1/reports${query ? `?${query}` : ''}`, { signal }); }
  getReport(id, signal) { return this.request(`/v1/reports/${encodeURIComponent(id)}`, { signal }); }
  createReport(input) { return this.request('/v1/reports', { method: 'POST', body: JSON.stringify(input) }); }
  addComment(id, input) {
    return this.request(`/v1/reports/${encodeURIComponent(id)}/comments`, {
      method: 'POST', body: JSON.stringify(input),
    });
  }
  verifyFix(id, input) {
    return this.request(`/v1/reports/${encodeURIComponent(id)}/verify`, {
      method: 'POST', body: JSON.stringify(input),
    });
  }
  updateTriage(id, input) {
    return this.request(`/v1/triage/reports/${encodeURIComponent(id)}`, {
      method: 'PATCH', body: JSON.stringify(input),
    });
  }
}

module.exports = { ...reportPolicy, FeedbackClient };
